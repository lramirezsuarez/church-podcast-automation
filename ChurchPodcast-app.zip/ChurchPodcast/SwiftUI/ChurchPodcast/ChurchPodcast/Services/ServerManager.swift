import Foundation
import Combine

/// Manages the lifecycle of the embedded Python Flask server.
/// The server is bundled inside the app and started/stopped with the app.
class ServerManager: ObservableObject {

    static let shared = ServerManager()

    @Published var isRunning = false
    @Published var startupError: String?

    private var process: Process?
    private let port = 5001

    /// Start the server. Looks for the Python venv and server.py relative to the app bundle.
    func start() {
        guard !isRunning else { return }

        // During development: server.py lives in the repo next to the Xcode project.
        // In a distributed app: bundle it inside Resources/.
        let serverPath = resolveServerPath()
        guard FileManager.default.fileExists(atPath: serverPath) else {
            startupError = "server.py not found at \(serverPath)"
            return
        }

        let pythonPath = resolvePythonPath()

        let p = Process()
        p.executableURL = URL(fileURLWithPath: pythonPath)
        p.arguments     = [serverPath]
        p.environment   = ProcessInfo.processInfo.environment.merging(
            ["CP_PORT": "\(port)", "PYTHONUNBUFFERED": "1"],
            uniquingKeysWith: { _, new in new }
        )

        // Pipe stdout/stderr so we can detect when server is ready
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError  = pipe

        p.terminationHandler = { [weak self] _ in
            DispatchQueue.main.async { self?.isRunning = false }
        }

        do {
            try p.run()
            process = p
        } catch {
            startupError = "Failed to start server: \(error.localizedDescription)"
            return
        }

        // Poll until the server responds (max 10 seconds)
        Task {
            for _ in 0..<20 {
                try? await Task.sleep(nanoseconds: 500_000_000)
                let alive = await APIService.shared.checkStatus()
                if alive {
                    await MainActor.run {
                        self.isRunning = true
                        SSEListener.shared.connect()
                    }
                    return
                }
            }
            await MainActor.run {
                self.startupError = "Server did not respond within 10 seconds."
            }
        }
    }

    func stop() {
        SSEListener.shared.disconnect()
        process?.terminate()
        process = nil
        isRunning = false
    }

    // MARK: - Path resolution

    private func resolveServerPath() -> String {
        // 1. Check if bundled inside the app
        if let bundled = Bundle.main.path(forResource: "server", ofType: "py",
                                          inDirectory: "python-server") {
            return bundled
        }
        // 2. Development: walk up from the app's directory to find the repo root
        let appDir  = Bundle.main.bundleURL.deletingLastPathComponent()
                          .deletingLastPathComponent().deletingLastPathComponent()
                          .deletingLastPathComponent()
        return appDir.appendingPathComponent("python-server/server.py").path
    }

    private func resolvePythonPath() -> String {
        // 1. Check for venv next to the repo root
        let appDir = Bundle.main.bundleURL
            .deletingLastPathComponent().deletingLastPathComponent()
            .deletingLastPathComponent().deletingLastPathComponent()
        let venvPython = appDir.appendingPathComponent(".venv/bin/python3").path
        if FileManager.default.fileExists(atPath: venvPython) {
            return venvPython
        }
        // 2. Homebrew Python 3.12
        let brewPython = "/opt/homebrew/opt/python@3.12/bin/python3.12"
        if FileManager.default.fileExists(atPath: brewPython) {
            return brewPython
        }
        // 3. System fallback
        return "/usr/bin/python3"
    }
}
