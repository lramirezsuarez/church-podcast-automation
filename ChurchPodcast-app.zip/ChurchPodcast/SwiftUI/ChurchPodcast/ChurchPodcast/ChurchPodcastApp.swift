import SwiftUI

@main
struct ChurchPodcastApp: App {

    @StateObject private var server = ServerManager.shared
    @StateObject private var vm     = PipelineViewModel()
    @StateObject private var sse    = SSEListener.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(vm)
                .environmentObject(server)
                .environmentObject(sse)
        }
        .windowStyle(.hiddenTitleBar)
        .windowResizability(.contentSize)
        .commands {
            CommandGroup(replacing: .newItem) {}  // remove File > New
            CommandMenu("Podcast") {
                Button("New Run") {
                    vm.resetForNewRun()
                }
                .keyboardShortcut("n", modifiers: .command)

                Divider()

                Button("Clean Files…") {
                    vm.goTo(.clean)
                    Task { await vm.loadCleanFiles() }
                }
                .keyboardShortcut("k", modifiers: [.command, .shift])
            }
        }
        .defaultSize(width: 680, height: 620)
        .onAppear { server.start() }  // not available pre-Ventura; see note below
    }
}

// Note: .onAppear on Scene is available macOS 13+.
// For earlier targets move server.start() into ContentView.onAppear.
